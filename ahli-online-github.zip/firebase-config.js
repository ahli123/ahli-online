// Firebase config مرتبط بمشروع ahli-online
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "ahli-online.firebaseapp.com",
  projectId: "ahli-online",
  storageBucket: "ahli-online.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};
firebase.initializeApp(firebaseConfig);