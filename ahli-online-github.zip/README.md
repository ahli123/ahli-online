
# الأهلي أونلاين

موقع تسجيل دخول الزوار ولوحة تحكم للإدارة، مرتبط بمشروع Firebase.

## محتويات المشروع:
- index.html – تسجيل دخول الزوار
- otp.html – صفحة رمز التحقق
- admin/login.html – صفحة دخول لوحة التحكم
- admin/admin.html – لوحة التحكم
- style.css – تصميم عام
- firebase-config.js – بيانات الاتصال بـ Firebase

## تعليمات:
- يمكن رفع الملفات إلى GitHub مباشرة
- أو نشرها باستخدام GitHub Pages (للموقع فقط)
- التحكم متاح من خلال admin/login.html
